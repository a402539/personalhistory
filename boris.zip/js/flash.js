function chk_Browser() {			 // �������� ���� Browser
	var flag = false;
	//cnf['browser']['mozilla'] = false;
	if(cnf['browser']['mozilla']) flag = true;
	else if(cnf['browser']['msie']) flag = true;
	else if(cnf['browser']['opera']) flag = true;
	else if(cnf['browser']['safari']) flag = true;
	if(!flag) {	  // ������� �� �������������� Browser
		var tHash = {
			'msie': 'http://www.microsoft.com/rus/windows/downloads/ie/getitnow.mspx'
			,'mozilla': 'http://www.mozilla.com/en-US/firefox/all-older.html#ru'
		};

		var tit = '�������������� ��������:<br>';
		tit += '<b>MSIE ������ �� 7.0</b> <a target="_blank" href="' + tHash.msie + '">������</a>';
		tit += '<br><b>FireFox(Mozilla) ������ �� 2.0</b></b> <a target="_blank" href="' + tHash.mozilla + '">������</a>';
		tit += '<hr>';
		tit += '������� <b>' + cnf['browser']['userAgent'] + '</b>';
		tit += '<br><b><span style="color: red">�� ��������������!</span></b>';

		var elem = document.createElement('DIV');
		elem.innerHTML = tit;
		elem.className = 'flash_chk';
		document.body.appendChild(elem);
		setPos(elem);
		return false;
	}
	return flag;
}

function chk_Flash() {			 // �������� Adobe Flash Player
	var flashVer = cnf['flashVer'];
	var flashReq = cnf['env']['reqFlashVer'];
	var flag = true;
	var flagOld = false;
	if(!flashVer) flag = false;  // �� ���������� Adobe Flash Player
	else if(flashVer.major < flashReq.major) flag = false;  // ����������� ������ < 10
	else if(flashVer.major == flashReq.major && flashVer.minor == flashReq.minor && flashVer.rev < flashReq.rev) { // ����������� ������ 10 rev < 12
		flag = false;
		flagOld = true;
	}
	if(!flag) {	  // ����� ���������� Adobe Flash Player
		var flinks = cnf['flashLinks'];
		var tHash = {
			'install': flinks.install.msie
			,'uninstall': flinks.uninstall.msie
		};
		if(!cnf['browser']['msie']) {
			tHash = {
				'install': flinks.install.not_msie
				,'uninstall': flinks.uninstall.msie
			};
		}
		var iLink = '������: <a target="_blank" href="' + tHash.install + '">Install Adobe Flash Player</a>';
		var tit = '��������� ���������� Adobe Flash Player ������ �� ����: <b>10.0.12</b>';
		if(flashVer && (flashVer.major < 10 || flagOld)) {
			tit += '<br>� ��� ���������� Flash Player ������: <b>' + flashVer.full + '</b>';
			tit += '<hr><ul><li>' + iLink + '</li>';
			tit += '<li>������ ���������� ��������������� ������ ������ - ������: <a target="_blank" href="' + tHash.uninstall + '">Uninstall Adobe Flash Player</a></li></ul>';
		} else {
			tit += '<br>' + iLink;
		}
		var elem = document.createElement('DIV');
		elem.innerHTML = tit;
		elem.className = 'flash_chk';
		document.body.appendChild(elem);
		setPos(elem);
		return false;
	}
	return true;
}

function getSwfVer() {	// JavaScript helper required to detect Flash Player PlugIn version information
	var flashVer = false;
	var np = navigator.plugins;
	if (np != null && np.length > 0) {	// NS/Opera version >= 3 check for Flash plugin in plugin array
		if (np["Shockwave Flash 2.0"] || np["Shockwave Flash"]) {
			var swVer2 = np["Shockwave Flash 2.0"] ? " 2.0" : "";
			var flashDescription = np["Shockwave Flash" + swVer2].description;
			var descArray = flashDescription.split(" ");
			var tempArrayMajor = descArray[2].split(".");
			var versionMajor = tempArrayMajor[0];
			var versionMinor = tempArrayMajor[1];
			var versionRevision = descArray[3];

			if (versionRevision == "") versionRevision = descArray[4];
			if (versionRevision[0] == "d") {
				versionRevision = versionRevision.substring(1);
			} else if (versionRevision[0] == "r") {
				versionRevision = versionRevision.substring(1);
				if (versionRevision.indexOf("d") > 0) {
					versionRevision = versionRevision.substring(0, versionRevision.indexOf("d"));
				}
			}

			if( versionRevision.length < 2 ) versionRevision += "0";
			flashVer = {
				'major': parseInt(versionMajor, 10)
				,'minor': parseInt(versionMinor, 10)
				,'rev': parseInt(versionRevision, 10)
				,'full': versionMajor + "." + versionMinor + "." + versionRevision
			};
		}
	}
	else if (navigator.userAgent.toLowerCase().indexOf("webtv/2.6") != -1) flashVer = 4;	// MSN/WebTV 2.6 supports Flash 4
	else if (navigator.userAgent.toLowerCase().indexOf("webtv/2.5") != -1) flashVer = 3;	// WebTV 2.5 supports Flash 3
	else if (navigator.userAgent.toLowerCase().indexOf("webtv") != -1) flashVer = 2;		// older WebTV supports Flash 2
	else if (cnf.browser.msie && cnf.browser.win) flashVer = chkVer();
	return flashVer;
}

function chkVer() {
	var ver = false;
	var axo;
	var e;

	try {		// version will be set for 7.X or greater players
		axo = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
		ver = axo.GetVariable("$version");
	} catch (e) {
	}

	if(!ver) {
		try {	// version will be set for 6.X players only
			axo = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
			ver = "WIN 6,0,21,0";
			axo.AllowScriptAccess = "always";		// throws if AllowScripAccess does not exist (introduced in 6.0r47)
			ver = axo.GetVariable("$version");	// safe to call for 6.0r47 or greater
		} catch (e) {
		}
	}

	if (!ver) {
		try {	// version will be set for 4.X or 5.X player
			axo = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.3");
			ver = axo.GetVariable("$version");
		} catch (e) {
		}
	}

	if (!ver) {
		try {	// version will be set for 3.X player
			axo = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.3");
			ver = "WIN 3,0,18,0";
		} catch (e) {
		}
	}

	if (!ver) {
		try {	// version will be set for 2.X player
			axo = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
			ver = "WIN 2,0,0,11";
		} catch (e) {
			ver = false;
		}
	}

	if (!ver) {
		try {		// version bad
			axo = new ActiveXObject("SWCtl.SWCtl");
			//ver = axo.ShockwaveVersion("");
			ver = "xx.xx";
		} catch (e) {
		}
	}

	if(ver) {
		var res = {	'full': ver, 'major': 1, 'minor': 2, 'rev': 3 };
		var mt = ver.match(/WIN (\d+),(\d+),(\d+),(\d+)/);
		if(mt && mt.length > 3) {
			res = {
				'full': ver
				,'major': parseInt(mt[1], 10)
				,'minor': parseInt(mt[2], 10)
				,'rev': parseInt(mt[3], 10)
			};
		}
		ver = res;
	}
return ver;
}


function randPorts(b, a) { if (Math.random()*5 > 2) return -1; return 1;}

function DOMContentLoadedEvent(e) {	// ��������� ������� ���������� DOM ������
	var arg = DOMContentLoadedEvent.arguments;
	if(!cnf) return;

	if(!chk_Flash() || !chk_Browser()) return;
	var uLogin = readCookie('uLogin') || '';
	user_ok(uLogin);
	return true;
	}

	function user_ok(uLogin) { // ���� �����������
		var logFormElem = document.getElementById('logFormElem');
		var prigElem = document.getElementById('prigElem');
		if(uLogin) {
			prigElem.style.display = 'block';
			logFormElem.style.display = 'none';
			var uLoginElem = document.getElementById('uLogin');
			uLoginElem.innerHTML = uLogin;
		} else {
			prigElem.style.display = 'none';
			logFormElem.style.display = 'block';
		}
	}

	function setPos(node, tEv, pos) { // ���������������� ����
		if(!pos) pos = 2;
		if(!tEv) tEv = {};
		//node = document.getElementById(node);
		//cnf.util.show(node);
		var xywh = {
			'clientWidth': document.body.clientWidth
			,'clientHeight': document.body.clientHeight
			,'scrollLeft': document.documentElement.scrollLeft || document.body.scrollLeft || 0
			,'scrollTop':  document.documentElement.scrollTop || document.body.scrollTop || 0
			,'clientX': tEv.pageX || tEv.clientX
			,'clientY': tEv.pageY || tEv.clientY
			,'offsetWidth': node.offsetWidth
			,'offsetHeight': node.offsetHeight
		};
		xywh.rightEdge = xywh.clientWidth - xywh.clientX;
		xywh.bottomEdge = xywh.clientHeight + xywh.scrollTop - xywh.clientY;
		xywh.left = xywh.clientX;
		xywh.top = xywh.clientY;

		switch(pos) {
			case 1:		// ������� ����� � ������
				if(xywh.rightEdge < xywh.offsetWidth) xywh.left -= xywh.offsetWidth;
				if(xywh.bottomEdge < xywh.offsetHeight) xywh.top -= xywh.offsetHeight;
				break;
			case 2:		// ������� � ������ ������
				xywh.left = xywh.scrollLeft + (xywh.clientWidth - xywh.offsetWidth)/2;
				xywh.top = xywh.scrollTop + (xywh.clientHeight - xywh.offsetHeight)/2;
				break;
			default: break;
		}
		node.style.left = xywh.left + 'px';
		node.style.top = xywh.top + 'px';
		node.style.zIndex = 10;
	}

/// End: ���������� ������ ��� Flash
function Events(par) {	// ����������/����� ��������� ������� � ������� � DOM + �������� �������������� ���������� ����������
	var res = false;
	if(!par || !par.tObj) return false;
	var evHash = par.evHash;
	if(typeof(evHash) !== 'object') return false;
	var tObj = par.tObj;
	if(typeof(tObj) === 'string') tObj = document.getElementById(tObj);
	if(typeof(tObj) !== 'object') return false;
	var browser = {};

	if(par.browser) {
		browser = par.browser;
		delete par.browser;
	} else {
		browser = getBrowser();
	}

	var tmp_data = { 'tmp': {} };
	var evtSets = { };
	if(cnf && cnf.data) {
		tmp_data = cnf.data;
		if(!tmp_data.tmp) tmp_data.tmp = {};
		if(!tmp_data.tmp.evPar) tmp_data.tmp.evPar = {};
		if(cnf.tmp.evtSets) evtSets = cnf.tmp.evtSets;
	}

	var prefix = tObj.id || 'glob';
	for(var prop in evHash) {
		var fn = evHash[prop].fn || "alert(this)";
		var vKey = prefix + '_' + prop;
		if(par.stop) {			// ������� �������
			if(tObj.detachEvent) tObj.detachEvent('on'+prop, fn);
			else tObj.removeEventListener(prop, fn, true);
			delete tmp_data.tmp.evPar[vKey];
			delete evtSets[vKey];
		} else {				// ������� �������
			if(evtSets['glob_' + prop]) return false;	// ��� ����������� �������
			if(prop === 'mousewheel') {
				if(browser['safari']) window.onmousewheel = fn;
				else if(tObj.attachEvent) { window.attachEvent('on'+prop, fn); document.attachEvent('on'+prop, fn); }
				else if(window.addEventListener) window.addEventListener('DOMMouseScroll', fn, true);
			} else {
				if(tObj.attachEvent) tObj.attachEvent('on'+prop, fn);
				else { tObj.addEventListener(prop, fn, true); if(par.tEv) par.tEv.preventDefault(); }
			}
			if(tmp_data.tmp && tmp_data.tmp.evPar && evHash[prop].par) tmp_data.tmp.evPar[vKey] = evHash[prop].par;
			evtSets[vKey] = 1;

		}
		res = true;
	}
	return res;
}

function prpPar() {			 // ������������� ���������� �� �������� DOM ������
	var out = { 'par': {} };
	var pt = document.URL.toString();
	out['nURL'] = pt;

	var pt1 = pt.match(/http:\/\/([^\/]+)\//);
	if(pt1) {
		out['sIP_Port'] = pt1[1];
		out['sHost'] = 'http://'+out['sIP_Port'];
		out['sHostLogout'] = 'http://' + out['sIP_Port'].replace(/^game./, '');
		out['sIP'] = out['sIP_Port'].replace(/:\d+/, '');
	}
	var i2 = out['nURL'].lastIndexOf('?');
	if (i2>0) {
		out['par'] = {};
		out['pURL'] = out['nURL'].substring(0, i2);
		var tmp = out['nURL'].substring(i2+1, out['nURL'].length );
		for(var i=0, pt = tmp.split(/\&/);i<pt.length;i++) {
			var pp = pt[i].split(/=/);
			if(pp && pp.length == 2) {
				pp[1] = pp[1].replace(/\#.+/, '');
				if(pp[1]) out['par'][pp[0]] = pp[1];
			}
		}
	}
	return out;
}

function getBrowser() {	//	����������� ���� ��������
	var b = navigator.userAgent.toLowerCase();
	var app = navigator.appVersion.toLowerCase();

	var brArr = ['safari', 'opera', 'msie', 'mozilla']; // Figure out what browser is being used
	var browser = {
		'userAgent': b,
		'appVersion': app,
		'win': (app.indexOf("win") != -1 ? true : false),
		'version': (b.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/) || [])[1],
		'safari': /webkit/.test(b),
		'opera': /opera/.test(b),
		'msie': /msie/.test(b) && !/opera/.test(b),
		'mozilla': /mozilla/.test(b) && !/(compatible|webkit)/.test(b)
	};

	for(var i=0; i<brArr.length; i++){ if(browser[brArr[i]]) { browser.type = brArr[i]; break; }}
	return browser;
}

var adobe_url = 'http://www.adobe.com/shockwave/download/download.cgi?';
adobe_url += 'P1_Prod_Version=ShockwaveFlash';
var cnf = {
	'cont': 'flash'
	,'flashName': 'au.swf'
	,'env': {
		'ver': '2.0'
		,'nURL': document.URL.toString()
		,'id_pc': ''
		,'ports': []
		,'sIP': ''
        ,'reqFlashVer': {                // ����������� ������ Flash Player 10.0.12.36
            'major': 10
            ,'minor': 0
            ,'rev': 12
        }
	}
	,'browser': getBrowser()
	,'par': prpPar()
	,'flashLinks': {                    // ������ �� Adobe Flash Player
		'install': {
			'msie':         adobe_url + '&P2_Platform=Win32&P3_Browser=MSIE'
			,'not_msie':    adobe_url + 'http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash&P2_Platform=Win32&P3_Browser=Netscape'
			,'MacOSX':      adobe_url + '&P2_Platform=MacOSX'
			,'Linux':       adobe_url + '&P2_Platform=Linux'
			,'Intel':       adobe_url + '&P2_Platform=Intel'
			,'Solaris':     adobe_url + '&P2_Platform=Solaris'
			,'pocketpc':    'http://www.adobe.com/products/flashplayer_pocketpc/downloads/player.html'
			,'hp':          'http://www.hp.com/support/macromedia_software/'
		}
		,'uninstall': {
			'msie':         'http://fpdownload.macromedia.com/get/flashplayer/current/uninstall_flash_player.exe'
			,'MacOSX':      'http://fpdownload.macromedia.com/get/flashplayer/current/uninstall_flash_player_osx.dmg'
		}
	}
};
cnf['flashVer'] = getSwfVer();

Events({'tObj': window, 'evHash': {'load': {'fn': DOMContentLoadedEvent} }, 'browser': cnf['browser'] });

function createCookie(name, value, days) {
	var expires = '';
	if(days) { var date=new Date(); date.setTime(date.getTime()+(days*24*60*60*1000)); expires="; expires="+date.toGMTString(); }
	document.cookie = name+"="+escape(value)+expires+"; path=/;"
}

function readCookie(name) {
	var nameEQ = name+"="; var ca = document.cookie.split(';');
	for(var i=0;i<ca.length;i++) {
		var c=ca[i]; while(c.charAt(0)===' ') c=c.substring(1,c.length);
		if(c.indexOf(nameEQ)===0){ 
			var tmp = c.substring(nameEQ.length,c.length);
			tmp = tmp.replace(/%25/g, '%');
			tmp = unescape(tmp);
			return tmp;
		}
	}
	return null;
}

function Movie(movieName, dObj) {
	if(!dObj) dObj = document;
	if(!movieName) movieName = movieName || 'sJsFlash';
	var userAgent = navigator.userAgent.toLowerCase();
	var msie = /msie/.test(userAgent) && !/opera/.test(userAgent);
	if(msie) return dObj[movieName]; // IE
	else { // Opera + FireFox
		if(dObj.embeds) {
			for(var i=0;i<dObj.embeds.length;i++) {
				var tObj = dObj.embeds[i];
				if(tObj.id === movieName) return tObj;
			}
		}
	}
	return null;
}

var imgView = null;
function onFlashLoad() {
	var arg = onFlashLoad.arguments;
	//alert('arg ' + arg);
}

function showFile(src) {
	if(!imgView) imgView = Movie('imgView');
	if(!imgView) return;
	imgView.loadFile(src);
}

